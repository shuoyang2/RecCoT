import os
import json
import logging
import re
import gc
import random
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional,Union
from sklearn.model_selection import train_test_split
import torch
from torch.utils.data import Dataset,DataLoader
import transformers
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainerCallback,
    set_seed,
    HfArgumentParser,
)
from trl import GRPOConfig, GRPOTrainer
from accelerate import Accelerator
from functools import partial
import swanlab
import time
import torch.distributed as dist
swanlab.login(api_key="tqTV3BYNeeEGKELKLEyvh")
from collections import Counter
import numpy as np
import copy
import tqdm
from sklearn.model_selection import StratifiedKFold
from vllm import LLM, SamplingParams
from dataclasses import replace
import json
import tqdm
from vllm import LLM, SamplingParams
from vllm.lora.request import LoRARequest
# ------------------- Data Classes -------------------
@dataclass
class ModelArguments:

    use_lora: bool = field(
        default=True,
        metadata={"help": "Whether to use LoRA fine-tuning"}
    )
    lora_r: int = field(
        default=8,
        metadata={"help": "LoRA attention dimension"}
    )
    lora_alpha: int = field(
        default=16,
        metadata={"help": "LoRA alpha parameter"}
    )
    lora_target_modules: str = field(
        default="q_proj,v_proj",
        metadata={"help": "Comma-separated list of modules to apply LoRA to"}
    )


from dataclasses import dataclass
@dataclass
class ScriptArgs:
    run_mode: str = "train"
@dataclass
class DataArguments:
    raw_path: str = field(
        default="./data/Baby_Products.jsonl",
        metadata={"help": "Path to raw dataset file"}
    )
    dataset_splits: str = field(
        default="train",
        metadata={"help": "Dataset splits to use"}
    )
    test_size: float = field(
        default=0.1,
        metadata={"help": "Percentage of data for testing"}
    )
    n_folds: int = field(
        default=2,
        metadata={"help": "Number of folds for cross-validation"}
    )


@dataclass
class GRPOTrainingArguments(GRPOConfig):
    model_name_or_path: str = field(
        default="./qwen0.5",
        metadata={"help": "Path to pretrained model or model identifier"}
    )
    output_dir: str = field(
        default="./results/Baby_Products_8",
        metadata={"help": "Output directory for results"}
    )
    model_max_length: int = field(
        default=512,
        metadata={"help": "Maximum sequence length"}
    )
    per_device_train_batch_size: int = field(
        default=8,
        metadata={"help": "Batch size per device for training"}
    )
    gradient_accumulation_steps: int = field(
        default=4,
        metadata={"help": "Number of gradient accumulation steps"}
    )
    learning_rate: float = field(
        default=2e-4,
        metadata={"help": "Initial learning rate"}
    )
    num_train_epochs: int = field(
        default=1,
        metadata={"help": "Total number of training epochs"}
    )
    logging_steps: int = field(
        default=50,
        metadata={"help": "Log every X updates steps"}
    )
    fp16: bool = field(
        default=True,
        metadata={"help": "Whether to use fp16 precision"}
    )
    seed: int = field(
        default=42,
        metadata={"help": "Random seed"}
    )
    max_steps: int =field(
        default=2000,
        metadata={"help": "Total number of training steps"}
    )


def generate_prompt_template(tokenizer, instruction: str, review: str) -> dict:
    """
    生成符合聊天模板结构的提示词，要求模型输出 JSON 格式

    参数:
        instruction (str): 产品标识信息
        review (str): 用户评论文本

    返回:
        dict: 包含完整提示词结构的字典
    """
    PROMPT_TEMPLATE = [
        {
            "role": "user",
            "content": f"""You are an expert in rating prediction. For the product with ID {instruction} and user review "{review}", analyze the review and predict its potential rating on a scale of 1 to 5 (higher values indicate more positive sentiment). Please output the result in JSON format with the following structure:
            {{
                "think": "analysis process",
                "answer": "predicted rating",
            }}
            """
        },
        {
            "role": "assistant",
            "content": "Okay, I will analyze according to the following steps:"
        }
    ]
    return {
        "prompt": tokenizer.apply_chat_template(
            PROMPT_TEMPLATE,
            tokenize=False,
            add_generation_prompt=True
        ),
        "instruction": instruction,
        "review": review
    }
# ------------------- Reward Functions -------------------
def format_reward_func(completions: List[str], **kwargs) -> List[float]:
    """Reward function for output format compliance"""
    rewards = []
    for comp in completions:
        try:
            json_output = json.loads(comp)

            # Check if it is a dictionary and contains necessary fields
            if isinstance(json_output, dict) and "think" in json_output and "answer" in json_output:
                rewards.append(1.0)
            else:
                rewards.append(0.0)
        except json.JSONDecodeError:
            rewards.append(0.0)
    return rewards


import re
import math
from typing import List, Dict
# def accuracy_reward_func(
#         completions: List[str],
#         targets: List[Dict],
#         class_freq: List[float],
#         **kwargs
# ) -> List[float]:
#     """Linear reward function based on prediction error"""
#     rewards = []
#     max_error = 4
#
#
#     # Pre calculated reward matrix
#     reward_matrix = {}
#     for true_label in range(1, 6):
#         row = []
#         for pred_label in range(1, 6):
#             error = abs(pred_label - true_label)
#             base_reward = 1 - 2 * (error / max_error)
#             row.append(round(base_reward, 4))
#         reward_matrix[true_label] = row
#
#     for comp, target in zip(completions, targets):
#         try:
#             json_output = json.loads(comp)
#             pred = json_output['answer']
#
#             pred = float(pred) if isinstance(pred, (int, float, str)) else None
#             if pred is None or not (1 <= pred <= 5):
#                 raise ValueError("Invalid prediction")
#
#             pred_label = int(pred)
#             pred_label = max(1, min(5, pred_label))
#
#             true_answer = target["rating"]
#             reward = reward_matrix[true_answer][pred_label - 1]
#             rewards.append(reward)
#
#             print(f"True: {true_answer}, Pred: {pred_label}, Reward: {reward}")
#
#         except (json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
#             rewards.append(-1.0)
#
#     return rewards
def accuracy_reward_func(
        completions: List[str],
        targets: List[Dict],
        class_freq: List[float],
        **kwargs
) -> List[float]:
    """
    Based on asymmetric index reward function, emphasizing low-frequency scoring weights
    Dynamically normalize the data from this batch to the range of [-1,1]
    """
    assert len(class_freq) == 5 and abs(sum(class_freq) - 1) < 1e-6
    for p in class_freq:
        if p <= 0:
            raise ValueError("Class_freq must be all greater than 0")

    # Reward function parameters
    alpha = kwargs.get('alpha', 1)
    beta = kwargs.get('beta', 1)
    gamma = kwargs.get('gamma', 8.0)
    base_scale = kwargs.get('base_scale', 0.8)
    penalty_scale = kwargs.get('penalty_scale', 0.2)
    steepness = kwargs.get('steepness', 4.0)

    freq_weight = [1 / math.sqrt(p) for p in class_freq]
    raw_rewards = []
    valid_indices = []

    # Step 1: Obtain Results
    for i, (comp, target) in enumerate(zip(completions, targets)):
        try:

            json_output = json.loads(comp)
            pred = json_output['answer']


            if isinstance(pred, str):
                pred = float(pred.strip())
            elif isinstance(pred, (int, float)):
                pred = float(pred)
            else:
                raise ValueError("Invalid prediction type")


            pred = max(1.0, min(5.0, pred))
            true_rating = float(target["rating"])
            true_rating = int(true_rating)


            error = pred - true_rating


            base_reward = math.exp(-(error) ** 2)


            if error < 0:
                penalty = -alpha * (math.exp(beta * abs(error)) - 1)
            else:
                penalty = -gamma * (1 - math.exp(-steepness * error) / (1 + error))

            raw_reward = base_scale * base_reward + penalty_scale * penalty

            weighted_reward = freq_weight[true_rating - 1] * raw_reward

            raw_rewards.append(weighted_reward)
            valid_indices.append(i)
            print(f"True: {true_rating}, Pred: {pred}, Raw: {weighted_reward:.4f}")

        except (json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
            raw_rewards.append(-10)
            print(f"Error processing: {e}")
    # Step 2: Calculate normalization parameters based on this batch of data
    if valid_indices:

        valid_rewards = [raw_rewards[i] for i in valid_indices]
        min_raw = min(valid_rewards)
        max_raw = max(valid_rewards)
        range_raw = max_raw - min_raw if max_raw != min_raw else 1.0
    else:

        min_raw, max_raw = -5.0, 1.0
        range_raw = max_raw - min_raw

    # Step 3: Normalize all rewards
    rewards = []
    for i, raw_reward in enumerate(raw_rewards):
        if i in valid_indices:
            normalized = 2 * (raw_reward - min_raw) / range_raw - 1
            normalized = max(-1.0, min(1.0, normalized))
            rewards.append(normalized)
            print(f"Sample {i}: Raw={raw_reward:.4f}, Norm={normalized:.4f}")
        else:
            rewards.append(-1.0)

    return rewards

def analysis_quality_reward_func(
        completions: List[str],
        min_length: int = 100,
        max_length: int = 200,
        **kwargs
) -> List[float]:
    rewards = []
    for comp in completions:
        try:
            json_output = json.loads(comp)
            thought = json_output['think']
            thought_length = len(thought.strip())

            normalized = (thought_length - min_length) / (max_length - min_length)
            reward = max(0.0, min(1.0, normalized))
            rewards.append(round(reward, 2))

        except:
            rewards.append(0.0)
    return rewards

# ------------------- Dataset Processing -------------------
def validate_json_structure(item: Dict) -> bool:
    required_fields = {
        "text": str,
        "rating": (float, int),
        "asin": str
    }

    for field, dtype in required_fields.items():
        if field not in item:
            return False
        if not isinstance(item[field], dtype):
            return False

    if not (1 <= item["rating"] <= 5):
        return False

    return True


def preprocess_text(text: str) -> str:
    """Clean and normalize English review text"""
    text = re.sub(r"\s+", " ", text)  # Remove extra whitespace
    text = re.sub(r"[^\w\s.,!?']", "", text)  # Remove special chars
    return text.strip().lower()


class GRPODataset(Dataset):
    def __init__(
        self,
        data_path: str,
        tokenizer: AutoTokenizer,
        split: str = "train",
        fold: int = 0,
        test_size: float = 0.1,
        n_folds: int = 2,
        seed: int = 42
    ):
        self.examples = []
        self.split = split
        self.class_freq = []
        tokenizer.padding_side = "left"
        self.tokenizer = tokenizer
        # Load raw data
        with open(data_path, "r") as f:
            items = [json.loads(line) for line in f]

        processed = []
        for item in items:
            if not validate_json_structure(item):
                continue
            try:

                review = preprocess_text(item["text"])
                rating = float(item["rating"])
                processed.append({
                    "instruction": item['asin'],
                    "input": review,
                    "output": (
                        f"<think>"
                        f"Review analysis: {review[:200]}... " 
                        f"Predicted rating: {rating}/5"
                        "</think>"
                        f"<answer>{rating}</answer>"

                    ),
                    "rating": rating,
                    "userid":item['user_id'],
                    "item_id":item['asin'],
                    'parent_id':item['parent_asin']
                })
            except (ValueError, KeyError) as e:
                logging.error(f"Data processing error: {str(e)}")
                continue

        # Data segmentation ------------------------------------------------
        from collections import defaultdict
        import random

        user_counts = defaultdict(int)
        for item in processed:
            user_counts[item["userid"]] += 1
        processed = [item for item in processed if user_counts[item["userid"]] >= 5]  # Only retain users with more than 5 interactions


        user_dict = defaultdict(list)
        item_dict = defaultdict(list)
        for item in processed:
            user_dict[item["userid"]].append(item)
            item_dict[item["item_id"]].append(item)

        # Ensure that each user and item has at least one sample in the training set
        required_samples = set()


        for user, samples in user_dict.items():
            chosen = random.Random(seed).choice(samples)
            required_samples.add(id(chosen))


        for item, samples in item_dict.items():
            if not any(id(s) in required_samples for s in samples):
                chosen = random.Random(seed).choice(samples)
                required_samples.add(id(chosen))


        required_data = [item for item in processed if id(item) in required_samples]
        remaining_data = [item for item in processed if id(item) not in required_samples]


        if remaining_data:
            stratify = [x["rating"] for x in remaining_data]
            train_add, test_data = train_test_split(
                remaining_data,
                test_size=test_size,
                stratify=stratify,
                random_state=seed
            )
        else:
            train_add, test_data = [], []


        full_train = required_data + train_add
        self.test_data = test_data

        # Cross validation segmentation
        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
        ratings = [x["rating"] for x in full_train]
        folds = list(skf.split(full_train, ratings))

        train_idx, val_idx = folds[fold]
        train_data = [full_train[i] for i in train_idx]
        val_data = [full_train[i] for i in val_idx]


        if split == "train":
            self.examples = train_data
        elif split == "val":
            self.examples = val_data
        elif split == "test":
            self.examples = self.test_data
        # Calculate the category distribution of actual usage data --------------------------------
        all_labels = [1, 2, 3, 4, 5]
        ratings = [ex["rating"] for ex in self.examples]
        total = len(ratings) or 1


        class_proportions = [
            ratings.count(label) / total
            for label in all_labels
        ]

        self.class_freq = np.array(class_proportions)
        print(f"[{split} set] Category distribution verification:")
        print("Tag | Quantity | Proportion")
        for label, prop in zip(all_labels, class_proportions):
            print(f"{label} | {ratings.count(label)} | {prop:.2%}")

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx) -> Dict[str, Any]:
        item = self.examples[idx]
        prompt = generate_prompt_template(
            self.tokenizer,
            item["instruction"],
            item["input"]
        )
        return {
            "reviewerID": item["userid"],
            "instruction": item["instruction"],
            "input": item["input"],
            "prompt": prompt["prompt"],
            "target": item["rating"],
            "parent_id": item["parent_id"],
            "completion": item["output"]
        }


class MSEMonitor:


    def __init__(self, tokenizer, sample_size=200):
        self.tokenizer = tokenizer
        self.sample_size = sample_size
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def prepare_dataset(self, dataset):

        indices = np.random.choice(
            len(dataset),
            size=min(self.sample_size, len(dataset)),
            replace=False
        )
        self.samples = [dataset[i] for i in indices]
        self.targets = [s["target"] for s in self.samples]

    @torch.no_grad()
    def evaluate(self, model):

        model.eval()
        y_true = []
        y_pred = []

        for sample in tqdm.tqdm(self.samples, desc="MSE监控"):
            inputs = self.tokenizer(
                sample["prompt"],
                return_tensors="pt",
                max_length=512,
                truncation=True
            ).to(self.device)

            outputs = model.generate(
                inputs.input_ids,
                max_new_tokens=50,
                pad_token_id=self.tokenizer.pad_token_id,
                temperature=0.01,
                do_sample=False
            )
            generated_ids = [
                output_ids[len(input_ids):] for input_ids, output_ids in zip(inputs.input_ids, outputs)
            ]
            response = self.tokenizer.batch_decode(generated_ids, skip_special_tokens=True)
            if isinstance(response, list):
                if len(response) == 0:
                    raise ValueError("Generated response is empty")
                response = response[0]
            if not response.strip():
                raise ValueError("Generated response is empty or only contains whitespace")


            try:
                json_response = json.loads(response)
                pred = json_response["answer"]
                if isinstance(pred, (int, float)):
                    pred = float(pred)
                elif isinstance(pred, str):
                    try:
                        pred = float(pred)
                    except ValueError:
                        pred = 0.0
                else:
                    pred = 0.0
                y_pred.append(pred)
                y_true.append(sample["target"])
            except json.JSONDecodeError:
                continue
            except KeyError as e:
                continue
            except Exception as e:
                print(e)
                continue
            except:
                continue
        if len(y_true) == 0:
            return {}
        print(y_pred)

        return {
            "mse": np.mean((np.array(y_true) - np.array(y_pred)) ** 2),
            "mae": np.mean(np.abs(np.array(y_true) - np.array(y_pred)))
        }

# ------------------- Training Setup -------------------
class SwanLabCallback(TrainerCallback):

    def __init__(self, model_args, data_args, training_args,train_dataset,val_dataset,monitor,log_interval,):
        self.model_args = model_args
        self.data_args = data_args
        self.training_args = training_args
        self.monitor = monitor
        self.log_interval = log_interval
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
    def on_train_begin(self, args, state, control, **kwargs):


        self.monitor.prepare_dataset(self.train_dataset)

    def on_step_end(self, args, state, control, **kwargs):

        if state.global_step % self.log_interval == 0:
            metrics = self.monitor.evaluate(kwargs['model'])
            if metrics:
                print(f"train/mse: {metrics['mse']}")
                print(f"train/mse: {metrics['mae']}")
                swanlab.log({
                    "train/mse": metrics["mse"],
                    "train/mae": metrics["mae"]
                }, step=state.global_step)

    def on_evaluate(self, args, state, control, **kwargs):

        self.monitor.prepare_dataset(self.val_dataset)
        metrics = self.monitor.evaluate(kwargs['model'])
        if metrics:
            swanlab.log({
                "eval/mse": metrics["mse"],
                "eval/mae": metrics["mae"]
            }, step=state.global_step)
    def on_log(self, args, state, control, logs=None, **kwargs):

        if not logs:
            return

        # Training indicator record
        if "loss" in logs:
            swanlab.log({
                "train/loss": logs["loss"],
                "train/learning_rate": logs.get("learning_rate", 0),
            }, step=state.global_step)

        # Evaluation indicator record
        if "rewards/accuracy_reward" in logs:
            rewards = {
                "reward/format": logs.get("rewards/format_reward_func", 0),
                "reward/accuracy": logs.get("rewards/accuracy_reward", 0),
                "reward/analysis_quality": logs.get("rewards/analysis_quality_reward_func", 0),
            }

            swanlab.log(rewards, step=state.global_step)


def safe_initialize():


    os.environ["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'

    cuda_mem = torch.cuda.get_device_properties(0).total_memory

    return {
        "trust_remote_code": True,
        "max_model_len": 16384,
        "gpu_memory_utilization": 0.85,
        "max_num_batched_tokens": 4096 if cuda_mem < 24e9 else 16384,
        "enforce_eager": True,
        "enable_prefix_caching": False,
        "task":"generate",
        "compilation_config": {"level": 0}
    }


class SaveBestModelCallback(TrainerCallback):
    def __init__(self, best_metrics, output_dir,fold,trainer):
        self.best_metrics = best_metrics
        self.output_dir = output_dir
        self.fold=fold
        self.trainer=trainer
    def on_log(self, args, state, control,logs=None, **kwargs):

        current_accuracy = logs.get('reward', -float('inf'))

        # Update the best model
        if current_accuracy > self.best_metrics['accuracy_reward']:
            self.best_metrics.update({
                'accuracy_reward': current_accuracy,
                'best_step': state.global_step,
            })
            print(self.best_metrics)
            save_path = os.path.join(self.output_dir, f"best_model")
            self.trainer.save_model(save_path)
            print(f"New best model saved at step {state.global_step} with accuracy: {current_accuracy:.4f}")


def grpo_train():
    # Initialize accelerator
    accelerator = Accelerator()
    # Parse arguments
    parser = HfArgumentParser((ModelArguments, DataArguments, GRPOTrainingArguments, ScriptArgs))
    model_args, data_args, training_args,_ = parser.parse_args_into_dataclasses()
    config = {

        **model_args.__dict__,
        **data_args.__dict__,
        **training_args.__dict__,
    }
    for k, v in config.items():
        if not isinstance(v, (int, float, str, bool, type(None))):
            config[k] = str(v)


    # Set seed
    transformers.set_seed(training_args.seed)

    # Initialize model and tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        training_args.model_name_or_path,
        padding_side='left',
        model_max_length=training_args.model_max_length
    )
    model = AutoModelForCausalLM.from_pretrained(
        training_args.model_name_or_path,
        torch_dtype=torch.bfloat16,
        attn_implementation="flash_attention_2",
        use_cache=False
    ).to('cuda')

    # Configure LoRA

    all_models = {}
    for fold in range(data_args.n_folds):
        best_metrics = {
            'accuracy_reward': -float('inf'),
            'best_step': 0,
        }
        model_args, data_args, training_args,_ = parser.parse_args_into_dataclasses()
        fold_output_dir = os.path.join(training_args.output_dir, f"fold_{fold}")
        swanlab.init(
            experiment_name="Baby_Products_8"+f"_qwen_fold{fold}",
            config=config,
            logdir=fold_output_dir
        )
        model_name = f"model_{fold}"
        if model_args.use_lora:
            lora_config = LoraConfig(
                r=model_args.lora_r,
                lora_alpha=model_args.lora_alpha,
                target_modules=model_args.lora_target_modules.split(","),
                lora_dropout=0.05,
                task_type="CAUSAL_LM"
            )
            all_models[model_name] =get_peft_model(model, lora_config)
        for name, param in all_models[model_name].named_parameters():
            if "transformer.layers" in name:
                param.requires_grad = False
        print(f"\n{'=' * 40}")
        print(f"Training Fold {fold + 1}/{data_args.n_folds}")
        print(f"{'=' * 40}\n")

        # Initialize dataset (pass in fold parameter)

        train_dataset = GRPODataset(
            data_args.raw_path,
            tokenizer,
            split="train",
            fold=fold
        )
        val_dataset = GRPODataset(
            data_args.raw_path,
            tokenizer,
            split="val",
            fold=fold
        )
        test_dataset = GRPODataset(
            data_args.raw_path,
            tokenizer,
            split="test",
        )
        # Initialize Trainer
        accuracy_reward = partial(
            accuracy_reward_func,
            targets=[{"rating": ex["rating"]} for ex in train_dataset.examples],
            class_freq=train_dataset.class_freq
        )
        accuracy_reward.__name__ = "accuracy_reward"
        training_args = replace(
            training_args,
            output_dir=training_args.output_dir + f"/fold_{fold}"
        )
        trainer = GRPOTrainer(
            model=all_models[model_name],
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            reward_funcs=[
                format_reward_func,
                accuracy_reward,
                analysis_quality_reward_func
            ]
        )

        mse_monitor = MSEMonitor(
            tokenizer=tokenizer,
            sample_size=200
        )
        trainer.add_callback(
            SaveBestModelCallback(
                best_metrics=best_metrics,
                output_dir=training_args.output_dir,
                fold=fold,
                trainer=trainer
            )
        )

        trainer.add_callback(SwanLabCallback(model_args, data_args, training_args, train_dataset, val_dataset,
                                             monitor=mse_monitor,
                                             log_interval=400
                                             ))

        # Record dataset information before training
        swanlab.log({
            "dataset/train_size": len(train_dataset),
            "dataset/val_size": len(val_dataset),
            "dataset/test_size": len(test_dataset)
        })
        # Training execution
        try:
            trainer.train()
            # trainer.train(resume_from_checkpoint=True)
        except Exception as e:
            print(f"Basic training errors: {str(e)}")
            raise

        accelerator.wait_for_everyone()


        if accelerator.is_main_process:
            trainer.save_model(
                os.path.join(training_args.output_dir, f"model_{fold}")
            )

        swanlab.finish()


def generate_cot_output(model, tokenizer, dataset, output_file,training_args) -> Dict:

    merged_model_dir = os.path.join(training_args.output_dir, f"best_model")

    default_config = {
        "max_new_tokens": 256,
        "max_num_batched_tokens" : 8192,
        "temperature": 0.7,
        "top_p": 0.9,
        "repetition_penalty": 1.1
    }


    try:
        # Collect all prompts in bulk
        prompts = []
        meta_data = []
        for review_data in tqdm.tqdm(dataset):
            try:
                # Build prompt template
                prompt = generate_prompt_template(
                    tokenizer,
                    review_data["instruction"],
                    review_data["input"]
                )["prompt"]

                prompts.append(prompt)
                meta_data.append(review_data)
            except KeyError as e:
                print(f"Missing data fields: {str(e)}，Skip current entry")
                continue

        sampling_params = SamplingParams(
            max_tokens=default_config["max_new_tokens"],
            temperature=default_config["temperature"],
            top_p=default_config["top_p"],
            repetition_penalty=default_config["repetition_penalty"],
            skip_special_tokens=True
        )

        outputs = model.generate(prompts, sampling_params,lora_request=LoRARequest("sql_adapter", 1, merged_model_dir))

        predictions = []
        true_values = []
        with open(output_file, "w", encoding="utf-8") as f:
            for idx, (output, review_data) in tqdm.tqdm(enumerate(zip(outputs, meta_data))):
                try:
                    response = output.outputs[0].text.strip()

                    json_response = json.loads(response)
                    think_value = json_response["think"]
                    rating_value = json_response.get("answer", None)
                    try:
                        rating_value = float(rating_value)
                        predictions.append(rating_value)
                        true_values.append(review_data['target'])
                    except ValueError:
                        rating_value = None
                    combined_review = (
                        f"{review_data['input']}\n"
                        f"This is another model generated chain of thought that you can refer to, and there may be errors in this. {think_value}"
                        if think_value
                        else review_data['input']
                    )

                    entry = {
                        "user_id": review_data["reviewerID"],
                        "item_id": review_data["instruction"],
                        "user_rating": review_data["target"],
                        "review":review_data["input"],
                        "predict":rating_value,
                        "user_review": combined_review,
                        "parent_id": review_data["parent_id"]
                    }

                    f.write(json.dumps(entry) + "\n")

                except json.JSONDecodeError:
                    print(f"JSON parsing failed for entry {idx}, original response: {response}")
                    continue
                except KeyError as e:
                    print(f"Entry {idx} is missing necessary field: {str (e)}")
                    continue
                except Exception as e:
                    print(f"Error occurred while processing entry {idx}: {str (e)}")
                    continue
        mae = sum(abs(p - t) for p, t in zip(predictions, true_values)) / len(predictions)
        print(mae)
        return {"success": True, "error": None}

    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    config = safe_initialize()
    parser = HfArgumentParser((ModelArguments, DataArguments, GRPOTrainingArguments, ScriptArgs))
    model_args, data_args, training_args, script_args = parser.parse_args_into_dataclasses()
    print(data_args.raw_path)
    if script_args.run_mode == "train":
        grpo_train()
    elif script_args.run_mode == "infer":
        for fold in range(data_args.n_folds):
            print(fold)
            _,_,training_args,_ = parser.parse_args_into_dataclasses()
            training_args = replace(
            training_args,
            output_dir=training_args.output_dir + f"/fold_{fold}"
            )
            print(training_args.output_dir)
            merged_model_dir = os.path.join(training_args.output_dir, f"best_model")
            tokenizer = AutoTokenizer.from_pretrained(
                training_args.model_name_or_path,
                padding_side='left',
                model_max_length=training_args.model_max_length
            )
            val_dataset = GRPODataset(
                data_args.raw_path,
                tokenizer,
                split="val",
                fold=fold
            )
            test_dataset = GRPODataset(
                data_args.raw_path,
                tokenizer,
                split="test",
            )
            vllm_model = LLM(
                model=training_args.model_name_or_path,
                enable_lora=True,
                **config
            )
            try:

                print(generate_cot_output(
                    vllm_model, tokenizer, val_dataset,
                    f"./data/Baby_Products_8/val_fold{fold}.jsonl",
                    training_args=training_args,
                ))

                print(generate_cot_output(
                    vllm_model, tokenizer, test_dataset,
                    f"./data/Baby_Products_8/test_fold{fold}.jsonl",
                    training_args=training_args,
                ))
                continue

            finally:

                del vllm_model
                torch.cuda.empty_cache()
                gc.collect()




