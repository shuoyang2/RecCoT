#!/bin/bash
#
#SBATCH --job-name=2-fold-train-then-infer
#SBATCH --output=./output/output_%j.txt
#SBATCH --error=./output/errors_%j.txt
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=32G
#SBATCH --time=20-0
#SBATCH --gres=gpu:1

# 训练阶段：所有 fold 的训练
accelerate launch \
--num_processes=1 \
--mixed_precision=fp16 \
--gradient_accumulation_steps=4 \
--main_process_port=29554 \
CoT.py --run_mode train  # 新增参数指定模式

# 推理阶段：所有 fold 的推理
accelerate launch \
--num_processes=1 \
--mixed_precision=fp16 \
--gradient_accumulation_steps=4 \
--main_process_port=29538 \
CoT.py --run_mode infer  # 新增参数指定模式