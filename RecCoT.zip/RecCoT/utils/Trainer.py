import torch.nn as nn
import torch
import torch.nn.functional as F
import random
from transformers import BertModel, BertTokenizer,BertConfig
from peft import LoraModel, get_peft_model, LoraConfig
from .help import padding_cls,padding_item_cls

class TransLayer(nn.Module):
    def __init__(self, config):
        super(TransLayer, self).__init__()
        self.config = config
        self.layer_num = config['layer_num']
        self.dropout = nn.Dropout(config['dropout'])


        self.layers_mul = nn.ModuleList([
            nn.MultiheadAttention(embed_dim=768, num_heads=12)
            for _ in range(self.layer_num)
        ])
        self.layers_feed1 = nn.ModuleList([
            nn.Linear(768, 768 * 4) for _ in range(self.layer_num)
        ])
        self.layers_feed2 = nn.ModuleList([
            nn.Linear(768 * 4, 768) for _ in range(self.layer_num)
        ])
        # LayerNorm
        self.norm1 = nn.ModuleList([nn.LayerNorm(768) for _ in range(self.layer_num)])
        self.norm2 = nn.ModuleList([nn.LayerNorm(768) for _ in range(self.layer_num)])

        for attn in self.layers_mul:
            nn.init.xavier_uniform_(attn.in_proj_weight)
        for fc in self.layers_feed1:
            nn.init.kaiming_normal_(fc.weight, nonlinearity='relu')

    def forward(self, x, pad_mask):
        x = x.permute(1, 0, 2)
        for i in range(self.layer_num):
            # Pre-LN
            x_norm = self.norm1[i](x)
            x1, _ = self.layers_mul[i](
                x_norm, x_norm, x_norm,
                key_padding_mask=pad_mask
            )
            x = x + self.dropout(x1)

            # Pre-LN
            x_norm = self.norm2[i](x)
            x1 = self.layers_feed1[i](x_norm)
            x1 = F.relu(x1)
            x1 = self.dropout(x1)
            x1 = self.layers_feed2[i](x1)
            x = x + self.dropout(x1)

        x = x.permute(1, 0, 2)
        return x


class InfoNCELoss(nn.Module):
    """
    对比学习的loss
    """
    def __init__(self, temperature=0.2):
        super(InfoNCELoss, self).__init__()
        self.temperature = temperature

    def forward(self, anchor, positive, negative):
        # Reshape positive and negative tensors
        # anchor = anchor.view(-1, 768)
        # positive_flat = positive.view(-1, 768)
        # negative_flat = negative.view(-1, 768)
        anchor = anchor.view(-1, 1536)
        positive_flat = positive.view(-1, 1536)
        negative_flat = negative.view(-1, 1536)
        # Calculate similarity matrix
        pos_sim = torch.matmul(anchor, positive_flat.t()) / self.temperature
        neg_sim = torch.matmul(anchor, negative_flat.t()) / self.temperature
        # Construct label vector
        bsz = anchor.size(0)
        labels = torch.zeros(bsz, dtype=torch.long).to(anchor.device)
        # Calculate loss
        logins = torch.cat([pos_sim, neg_sim], dim=1)
        loss = F.cross_entropy(logins, labels)
        return loss


class TripletLoss(nn.Module):
    """
    对比学习的loss
    """
    def __init__(self, margin=1.0):
        super(TripletLoss, self).__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        distance_positive = F.pairwise_distance(anchor, positive, p=2)
        distance_negative = F.pairwise_distance(anchor, negative, p=2)
        loss = F.relu(distance_positive - distance_negative + self.margin)
        return torch.mean(loss)


class Trainer(nn.Module):
    """
    使用cls训练transformer模型
    """
    def __init__(self, config):
        super(Trainer, self).__init__()
        self.config = config
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
        self.transformer = TransLayer(config)
        self.linear = nn.Linear(768+192, 768)
        self.mul_attn = torch.nn.MultiheadAttention(768, 8, 0, batch_first=True)
        self.user_embedding = nn.Embedding(config['user_dim'], 768)
        self.item_embedding = nn.Embedding(config['item_dim'], 768)
        self.triplet_loss = TripletLoss(margin=1.0)
        self.dropout = nn.Dropout(config['dropout'])
        self.max_len=config['max_len']
        # self.contrastive_loss = InfoNCELoss(temperature=0.2)
        self.attention_linear = nn.Linear(1536, 1)
        self._initialize_parameters()
        self.is_test=False
        self.user_review_cache = {}
        self.item_review_cache = {}
        self.device=torch.device("cuda")
        self.model=SaveClsModel().to(self.device)
    def cache_user_reviews(self, user_ids, review_embeddings):
        """增量缓存用户特征"""
        for uid, emb in zip(user_ids, review_embeddings):
            uid = int(uid)
            if uid not in self.user_review_cache:
                self.user_review_cache[uid] = emb.detach().cpu()

    def cache_item_reviews(self, item_ids, review_embeddings):
        """增量缓存物品特征"""
        for iid, emb in zip(item_ids, review_embeddings):
            iid = int(iid)
            if iid not in self.item_review_cache:
                self.item_review_cache[iid] = emb.detach().cpu()

    def get_cached_reviews(self, ids, is_user=True):
        """获取缓存特征并迁移到当前设备"""
        cache_dict = self.user_review_cache if is_user else self.item_review_cache
        batch_embs = []
        for uid in ids:
            uid = int(uid)
            if uid in cache_dict:
                emb = cache_dict[uid].to(self.device)
                batch_embs.append(emb)
            else:

                batch_embs.append(None)
        return batch_embs

    def _initialize_parameters(self):
        for p in self.parameters():
            if p.requires_grad and p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def forward(self, data,user_interactions,is_test=False):
        user_id, item_id = data['user_id'], data['item_id']

        if is_test:
            # Retrieve cached or real-time generated features
            user_features = []

            for idx, uid in enumerate(user_id):
                cached = self.get_cached_reviews(uid.unsqueeze(0), is_user=True)[0]
                if cached is not None:
                    user_features.append(cached)
                else:
                    inputs = self.tokenizer(
                        "",
                        padding="max_length",
                        truncation=True,
                        max_length=1024,
                        return_tensors="pt",
                        add_special_tokens=True
                    ).to(self.device)
                    feature=self.model(inputs["input_ids"],inputs["attention_mask"])
                    feature=padding_cls(feature, self.max_len,False).to(torch.float32).to(self.device)
                    user_features.append(feature)

            item_features = []
            for idx, iid in enumerate(item_id):
                cached = self.get_cached_reviews(iid.unsqueeze(0), is_user=False)[0]
                if cached is not None:
                    item_features.append(cached)
                else:
                    inputs = self.tokenizer(
                        "",
                        padding="max_length",
                        truncation=True,
                        max_length=1024,
                        return_tensors="pt",
                        add_special_tokens=True
                    ).to(self.device)
                    feature=self.model(inputs["input_ids"],inputs["attention_mask"])
                    feature=padding_cls(feature,self.max_len,False).to(torch.float32).to(self.device)
                    item_features.append(feature)
            user_embed = self.user_embedding(user_id).view(-1, 1, 768)
            item_embed = self.item_embedding(item_id).view(-1, 1, 768)

            user_features = torch.stack(user_features, dim=0)
            item_features = torch.stack(item_features, dim=0)
            user_mask, item_mask = (user_features == 0)[:, :, 0], (item_features == 0)[:, :, 0]
            user_features = self.transformer(user_features, user_mask)
            item_features = self.transformer(item_features, item_mask)
            # Cross attention computation
            user_attn = self.mul_attn(
                query=item_embed,
                key=user_features,
                value=user_features,
                key_padding_mask=user_mask
            )[0].squeeze()

            # Item side attention
            item_attn = self.mul_attn(
                query=user_embed,
                key=item_features,
                value=item_features,
                key_padding_mask=user_mask
            )[0].squeeze()

            pooled = torch.cat((user_attn, item_attn), dim=-1)
            dropout_output = self.dropout(pooled)
            return self.attention_linear(dropout_output).squeeze(-1), 0

        user_input, item_input = data['user_input'], data['item_input']
        if item_id in user_interactions[user_id]:
            index = user_interactions[user_id].index(item_id)
            if index < len(user_input):
                user_input.pop(index)
        batch_size = user_id.size(0)
        user_embed, item_embed = self.user_embedding(user_id).view(-1, 1, 768), self.item_embedding(item_id).view(-1, 1, 768)
        user_mask, item_mask = (user_input == 0)[:, :, 0], (item_input == 0)[:, :, 0]
        user_review_embed = self.transformer(user_input, user_mask)
        item_review_embed = self.transformer(item_input, item_mask)
        self.cache_user_reviews(user_id, user_input.detach())
        self.cache_item_reviews(item_id, item_input.detach())
        # cross attention
        user_review_attn = self.mul_attn(query=item_embed, key=user_review_embed, value=user_review_embed, key_padding_mask=user_mask)[0].squeeze()
        item_review_attn = self.mul_attn(query=user_embed, key=item_review_embed, value=item_review_embed, key_padding_mask=user_mask)[0].squeeze()

        # user
        user_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)])
        user_review_attn_pos = user_embed[user_review_attn_pos_idx].squeeze(1)
        user_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)])
        user_review_attn_neg = user_embed[user_review_attn_neg_idx].squeeze(1)
        user_review_attn_loss = self.triplet_loss(user_review_attn, user_review_attn_pos, user_review_attn_neg)
        # item
        item_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)])
        item_review_attn_pos = item_embed[item_review_attn_pos_idx].squeeze(1)
        item_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)])
        item_review_attn_neg = item_embed[item_review_attn_neg_idx].squeeze(1)
        item_review_attn_loss = self.triplet_loss(item_review_attn, item_review_attn_pos, item_review_attn_neg)

        match_loss = user_review_attn_loss + item_review_attn_loss  # The loss of comparative learning

        pooled_output = torch.cat((user_review_attn, item_review_attn), dim=-1)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.attention_linear(dropout_output).squeeze(-1)
        return linear_output, match_loss
class SaveClsModel(nn.Module):

    def __init__(self):
        super(SaveClsModel, self).__init__()
        R = 32
        LORA_ALPHA = 32
        LORA_DROPOUT = 0.5
        TARGET_MODULES = ["query", "value", "linear", "dense"]

        self.config1 = LoraConfig(
            r=R,
            lora_alpha=LORA_ALPHA,
            target_modules=TARGET_MODULES,
            lora_dropout=LORA_DROPOUT,
            bias="none",
        )


        self.bert_config = BertConfig.from_pretrained('bert-base-cased')
        self.bert_config.max_position_embeddings = 1024
        ckpt_path = "./pretrain/Industrial_and_Scientific_8/my_model.pth"
        print(ckpt_path)
        self.bert = self.get_lora_model(self.config1, ckpt_path)
        self.tokenizer = BertTokenizer.from_pretrained("bert-base-cased")
        self.tokenizer.model_max_length = 1024

    def _init_extended_bert(self):

        model = BertModel(self.bert_config)

        pretrained_model = BertModel.from_pretrained('bert-base-cased')
        pretrained_dict = pretrained_model.state_dict()

        filtered_dict = {k: v for k, v in pretrained_dict.items()
                         if "position_embeddings" not in k}
        model.load_state_dict(filtered_dict, strict=False)

        with torch.no_grad():
            original_weights = pretrained_model.embeddings.position_embeddings.weight.data
            new_weights = torch.cat([original_weights, original_weights[:512]], dim=0)
            model.embeddings.position_embeddings.weight.data = new_weights

        return model

    def get_lora_model(self, config, ckpt_path):

        base_model = self._init_extended_bert()

        lora_model = get_peft_model(base_model, config)
        lora_model.print_trainable_parameters()

        if ckpt_path:
            checkpoint = torch.load(ckpt_path)

            fixed_checkpoint = {}
            for k, v in checkpoint['model_state_dict'].items():
                new_key = k.replace("base_model.model.bert", "base_model.model")
                fixed_checkpoint[new_key] = v

            if "base_model.model.embeddings.position_embeddings.weight" in fixed_checkpoint:
                current_pos = lora_model.base_model.model.embeddings.position_embeddings.weight.data
                loaded_pos = fixed_checkpoint["base_model.model.embeddings.position_embeddings.weight"]

                if current_pos.shape[0] != loaded_pos.shape[0]:
                    min_len = min(current_pos.shape[0], loaded_pos.shape[0])
                    current_pos[:min_len] = loaded_pos[:min_len]
                    fixed_checkpoint["base_model.model.embeddings.position_embeddings.weight"] = current_pos

            lora_model.load_state_dict(fixed_checkpoint, strict=False)

        lora_model.merge_and_unload()
        return lora_model

    def forward(self, input_ids, input_mask):
        output = self.bert(input_ids, attention_mask=input_mask)
        cls = output.last_hidden_state[:, 0, :]
        return cls


class PretrainBert(nn.Module):
    def __init__(self, use_meta, dropout=0.5):
        super(PretrainBert, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-cased')
        self.dropout = nn.Dropout(dropout)
        self.linear1 = nn.Linear(768 + (192 if use_meta else 0), 1)
        self.relu = nn.ReLU()

    def pretrain(self, data, use_meta=True):
        input_ids, input_mask = data['input_ids'], data['input_mask']
        _, pooled_output = self.bert(input_ids=input_ids, attention_mask=input_mask, return_dict=False)
        dropout_output = self.dropout(pooled_output)
        if use_meta:
            dropout_output = torch.cat((dropout_output, data['cls']), -1)
        linear_output = self.linear1(dropout_output)
        return linear_output.squeeze(-1)

    def save_cls(self, data):
        output = self.bert(data['input_ids'], attention_mask=data['input_mask'])
        cls = output.last_hidden_state[:, 0, :]
        return cls

    def forward(self, data, use_meta=True, save_cls=False):
        if save_cls:
            return self.save_cls(data)
        else:
            return self.pretrain(data, use_meta)

