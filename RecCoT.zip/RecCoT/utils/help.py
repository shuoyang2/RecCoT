import json
import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from collections import defaultdict
import random
import os
import torch.nn as nn
import time


def seed_everything(config):
    random.seed(config['seed'])
    np.random.seed(config['seed'])
    os.environ['PYTHONHASHSEED'] = str(config['seed'])
    torch.manual_seed(config['seed'])
    torch.cuda.manual_seed_all(config['seed'])
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    if torch.cuda.is_available():
        config['use_cuda'] = False
    elif config['use_cuda']:
        torch.cuda.manual_seed(config['seed'])


def split_data(data, train_ratio, eval_ratio):
    np.random.shuffle(data)  # Shuffle the data randomly
    num_total = len(data)

    num_train = int(num_total * train_ratio)
    num_eval = int(num_total * eval_ratio)

    train_data = data[:num_train]
    eval_data = data[num_train:num_train + num_eval]
    test_data = data[num_train + num_eval:]
    return train_data, eval_data, test_data


def model_init(model):
    print('model.para_init')
    for p in model.parameters():
        if p.requires_grad and p.dim() > 1:
            nn.init.xavier_uniform_(p)


def check_dir(d):
    if not os.path.exists(d):
        print("Directory {} does not exist. Exit.".format(d))
        exit(1)


def check_files(files):
    for f in files:
        if f is not None and not os.path.exists(f):
            print("File {} does not exist. Exit.".format(f))
            exit(1)


def ensure_dir(d):
    if not os.path.exists(d):
        print("Directory {} do not exist; creating...".format(d))
        os.makedirs(d)


def print_config(config):
    info = "Running with the following configs:\n"
    for k, v in config.items():
        info += "\t{} : {}\n".format(k, str(v))
    print("\n" + info + "\n")
    return


def look_file(config):
    """
    用户的总数是478235	商品的总数是266414
    用户的平均评论数是1.7481071021568895	商品的平均评论数是3.137995750974048
    """
    data = []
    with open(config["cls_path"], "r") as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)
            if config['test'] and len(data) > 500:
                break
    user_reviews, item_reviews = defaultdict(list), defaultdict(list)
    for d in data:
        user_reviews[d['user_id']].append(d['item_id'])
        item_reviews[d['item_id']].append(d['user_id'])

    len_user, len_item = [], []
    for key in user_reviews.keys():
        len_user.append(len(user_reviews[key]))
    for key in item_reviews.keys():
        len_item.append(len(item_reviews[key]))
    print("用户的总数是{}\t商品的总数是{}".format(len(user_reviews), len(item_reviews)))
    print("用户的平均评论数是{}\t商品的平均评论数是{}".format(np.mean(len_user), np.mean(len_item)))


def look_tsne(config):
    data = []
    # 读取评论数据的cls
    with open(config["cls_path"], "r") as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)
            # if len(data) >= 200 and config['test']:
            #     break
    # 建立用户和商品的id
    user_index_to_id = {}
    item_index_to_id = {}
    for d in data:
        user_id, item_id = d['user_id'], d['item_id']
        if user_id not in user_index_to_id:
            user_index_to_id[user_id] = len(user_index_to_id)
        if item_id not in item_index_to_id:
            item_index_to_id[item_id] = len(item_index_to_id)
    user_len, item_len = len(user_index_to_id), len(item_index_to_id)
    print("用户的总数是{}\t商品的总数是{}".format(user_len, item_len))
    for d in data:
        d['user_id'] = user_index_to_id[d['user_id']]
        d['item_id'] = item_index_to_id[d['item_id']]

    iid, cls = [], []
    for d in data:
        iid.append(d['item_id'])
        cls.append(d['cls'])

    user_cls = torch.tensor(cls).squeeze().numpy()
    user_cls = StandardScaler().fit_transform(user_cls)
    user_cls = PCA(n_components=50).fit_transform(user_cls)
    embedding = TSNE(perplexity=30, n_iter=1000).fit(user_cls)
    plt.scatter(embedding[:, 0], embedding[:, 1], c=iid, cmap='viridis')
    plt.colorbar()
    plt.title('t-SNE embedding of the Iris dataset')
    plt.xlabel('Dimension 1')
    plt.ylabel('Dimension 2')
    plt.show()


def save_cls(data, path="datasets/reviews_digital_music_cls.json", mode='a'):
    """追加模式写入数据，避免全量数据内存堆积"""
    with open(path, mode) as f:
        for item in data:
            json.dump(item, f)
            f.write("\n")  # 每行一个JSON对象


def to_cuda(data):
    if torch.cuda.is_available():
        for key in data.keys():
            data[key] = data[key].cuda()
    return data


def padding_cls(cls, max_len=25, use_meta=True):
    review_len = cls.size(0)
    if review_len >= max_len:
        return cls[-max_len:]
    else:
        x = torch.zeros(max_len, (768+192) if use_meta else 768)
        x[:review_len, :] = cls
        return x

def padding_item_cls(cls, max_len=25, use_meta=True):
    review_len = cls.size(0)
    if review_len >= max_len:
        return cls[-max_len:]
    else:
        x = torch.zeros(max_len, (768+192) if use_meta else 1536)
        x[:review_len, :] = cls
        return x
# class FileLogger:
#     """
#     A file logger that opens the file periodically and write to it.
#     """
#     def __init__(self, filename, header=None):
#         self.filename = filename + time.strftime("%Y-%m-%d %H-%M", time.localtime()) + '.log'
#         if os.path.exists(self.filename):
#             # remove the old file
#             os.remove(self.filename)
#         if header is not None:
#             with open(self.filename, 'w') as out:
#                 print(header, file=out)
#
#     def log(self, message):
#         with open(self.filename, 'a') as out:
#             print(message)
#             print(message, file=out)


class FileLogger:
    def __init__(self, config, pretrain=True):
        self.log_path = self.get_log_path(config, pretrain)
        with open(self.log_path, 'w') as out:
            print('log start:{}'.format(time.strftime("%Y-%m-%d %H-%M", time.localtime())), file=out)
            print("{}\t domain: {}".format("pretrain" if pretrain else "train", config['domain']), file=out)
            info = self.write_config(config)
            print(info, file=out)

    def log(self, message):
        with open('{}'.format(self.log_path), 'a') as out:
            print(message, file=out)
            print(message)

    @staticmethod
    def get_log_path(config, pretrain):
        path = 'log/' + "{}/".format("pretrain" if pretrain else "train") + config['domain']
        log_id = 1
        if not os.path.exists(path):
            os.makedirs(path)
        while 1:
            if os.path.exists('{}/{}.log'.format(path, log_id)):
                log_id += 1
            else:
                log_path = '{}/{}.log'.format(path, log_id)
                return log_path

    @staticmethod
    def write_config(config):
        info = "Running with the following configs:\n"
        for k, v in config.items():
            info += "\t{} : {}\n".format(k, str(v))
        print("\n" + info + "\n")
        return info


def timeing(f):
    def wrapper(*args, **kwargs):
        time1 = time.time()
        res = f(*args, **kwargs)
        name = f.__name__
        time2 = time.time()
        print("{}的运行时间:{:.2f}分钟".format(name, (time2-time1) / 60))
        return res
    return wrapper


def no_gard(f):
    def wrapper(*args, **kwargs):
        with torch.no_grad():
            res = f(*args, **kwargs)
            return res
    return wrapper
