from torch.utils.data import Dataset, DataLoader
import torch
from transformers import BertTokenizer
from .help import padding_cls,padding_item_cls


class LoidData(Dataset):
    def __init__(self, data, user_reviews, item_reviews):
        super(LoidData, self).__init__()
        self.data = data
        self.user_reviews = user_reviews
        self.item_reviews = item_reviews
        self.tokenizer = BertTokenizer.from_pretrained('Merged-Model')

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        user_reviews_input, item_reviews_input = [], []
        user_id, item_id, label = self.data[idx]['user_id_tensor'].item(), self.data[idx]['item_id_tensor'].item(), self.data[idx]['label_tensor']
        len_user_reviews = len(self.user_reviews[user_id])
        len_item_reviews = len(self.item_reviews[item_id])
        for j in range(5):
            if j < len_user_reviews:
                review = self.user_reviews[user_id][j]
            else:
                review = ""
            input_tokens = self.tokenizer(review, padding='max_length', truncation=True, max_length=128, add_special_tokens=True)
            input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
            attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
            user_reviews_input.append((input_id_tensor, attention_mask_tensor))
        for j in range(5):
            if j < len_item_reviews:
                review = self.item_reviews[item_id][j]
            else:
                review = ""
            input_tokens = self.tokenizer(review, padding='max_length', truncation=True, max_length=128, add_special_tokens=True)
            input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
            attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
            item_reviews_input.append((input_id_tensor, attention_mask_tensor))
        user_input_ids = torch.cat([t[0] for t in user_reviews_input], dim=0).unsqueeze(0)
        user_attention_masks = torch.cat([t[1] for t in user_reviews_input], dim=0).unsqueeze(0)
        item_input_ids = torch.cat([t[0] for t in item_reviews_input], dim=0).unsqueeze(0)
        item_input_mask = torch.cat([t[1] for t in item_reviews_input], dim=0).unsqueeze(0)
        return {"user_id": user_id, "item_id": item_id, "label": label,
                "user_input_ids": user_input_ids, "user_attention_masks": user_attention_masks,
                "item_input_ids": item_input_ids, "item_input_mask": item_input_mask}


class LoidLoader(DataLoader):
    def __init__(self, data, config):
        super(LoidLoader, self).__init__(data, batch_size=config["bs"], shuffle=False, collate_fn=self.collate_fn, drop_last=True)

    @staticmethod
    def collate_fn(batch):
        user_id = torch.tensor([data['user_id'] for data in batch], dtype=torch.long)
        item_id = torch.tensor([data['item_id'] for data in batch], dtype=torch.long)
        label = torch.tensor([data['label'] for data in batch]).float()
        user_input_ids = torch.cat([data['user_input_ids'] for data in batch])
        user_attention_masks = torch.cat([data['user_attention_masks'] for data in batch])
        item_input_ids = torch.cat([data['item_input_ids'] for data in batch])
        item_input_mask = torch.cat([data['item_input_mask'] for data in batch])

        return {"user_id": user_id, "item_id": item_id, "label": label,
                "user_input_ids": user_input_ids, "user_attention_masks": user_attention_masks,
                "item_input_ids": item_input_ids, "item_input_mask": item_input_mask}


class TransformerData(Dataset):
    def __init__(self, data):
        super(TransformerData, self).__init__()
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class TransformerLoader(DataLoader):
    def __init__(self, data, user_reviews, item_reviews, config):
        self.user_reviews = user_reviews
        self.item_reviews = item_reviews
        self.max_len = config["max_len"]
        super(TransformerLoader, self).__init__(data, batch_size=config["bs"], shuffle=False, collate_fn=self.collate_fn)

    def collate_fn(self, batch):
        user_id, item_id, rate, cls = ([data['user_id'] for data in batch],  [data['item_id'] for data in batch],
                                       [data['rate'] for data in batch],  [data["cls"] for data in batch])
        user_input, item_input, user_mask_len, item_mask_len = [], [], [], []
        for i, uid in enumerate(user_id):
            user_review_input = torch.tensor(self.user_reviews[user_id[i]])
            item_review_input = torch.tensor(self.item_reviews[item_id[i]])
            user_review_input = self.padding_cls(user_review_input, self.max_len)  # padding
            item_review_input = self.padding_cls(item_review_input, self.max_len)
            user_input.append(user_review_input)
            item_input.append(item_review_input)
        user_input = torch.stack(user_input)
        item_input = torch.stack(item_input)
        user_id = torch.tensor(user_id)
        item_id = torch.tensor(item_id)
        rate = torch.tensor(rate)
        return {"user_id": user_id, "item_id": item_id, "rate": rate, "user_input": user_input, "item_input": item_input}

    @staticmethod
    def padding_cls(cls, max_len=25):
        review_len = cls.size(0)
        if review_len >= max_len:
            return cls[:max_len]
        else:
            x = torch.zeros(max_len, 768)
            x[:review_len, :] = cls
            return x


class PretrainData(Dataset):
    def __init__(self, review_data, config, meta_data=None):
        super(PretrainData, self).__init__()
        self.review_data, self.meta_data, self.data = review_data, meta_data, []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        num_use_meta, num_no_meta = 0, 0
        if config['connect'] and meta_data is not None:
            for i, ele in enumerate(self.review_data):
                if ele['item_id'] in self.meta_data:
                    text = ele['text'] + self.meta_data[ele['item_id']]
                    num_use_meta += 1
                else:
                    text = ele['text']
                    num_no_meta += 1
                input_data = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
                input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
                self.data.append({"ids": input_ids, "mask": input_mask, "user_id": ele['user_id'], "item_id": ele['item_id'], "rate": ele['rate']})
        else:
            for i, ele in enumerate(self.review_data):
                input_data = self.tokenizer(ele['text'], padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
                input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
                self.data.append({"ids": input_ids, "mask": input_mask, "user_id": ele['user_id'], "item_id": ele['item_id'], "rate": ele['rate']})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["user_id"], self.data[idx]["item_id"], self.data[idx]['rate']


class PretrainLoader(DataLoader):
    def __init__(self, data, batch_size, shuffle=True):
        super(PretrainLoader, self).__init__(data, batch_size=batch_size, shuffle=shuffle, collate_fn=self.collate_fn)

    @staticmethod
    def collate_fn(batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        users_id = [data[2] for data in batch]
        items_id = [data[3] for data in batch]
        rate = [data[4] for data in batch]
        return {"input_ids": torch.tensor(input_ids), "input_mask": torch.tensor(input_mask),
                "user_id": torch.tensor(users_id), "item_id": torch.tensor(items_id), "rate": torch.tensor(rate).float()}


class SaveClsData(Dataset):
    def __init__(self, review_data, config, meta_data=None):
        super(SaveClsData, self).__init__()
        self.review_data, self.meta_data, self.data = review_data, meta_data, []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        num_use_meta, num_no_meta = 0, 0
        if config['connect'] and meta_data is not None:
            for i, ele in enumerate(self.review_data):
                if ele['item_id'] in self.meta_data:
                    text = ele['text'] + self.meta_data[ele['item_id']]
                    num_use_meta += 1
                else:
                    text = ele['text']
                    num_no_meta += 1
                input_data = self.tokenizer(text, padding='max_length', truncation=True, max_length=1024, add_special_tokens=True)
                input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
                self.data.append({"ids": input_ids, "mask": input_mask, "user_id": ele['user_id'], "item_id": ele['item_id'], "rate": ele['rate']})
        else:
            for i, ele in enumerate(self.review_data):
                input_data = self.tokenizer(ele['text'], padding='max_length', truncation=True, max_length=1024, add_special_tokens=True)
                input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
                self.data.append({"ids": input_ids, "mask": input_mask, "user_id": ele['user_id'], "item_id": ele['item_id'], "rate": ele['rate']})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["user_id"], self.data[idx]["item_id"], self.data[idx]['rate']


class SaveClsLoader(DataLoader):
    def __init__(self, data, batch_size, shuffle=True):
        super(SaveClsLoader, self).__init__(data, batch_size=batch_size, shuffle=shuffle, collate_fn=self.collate_fn)

    @staticmethod
    def collate_fn(batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        users_id = [data[2] for data in batch]
        items_id = [data[3] for data in batch]
        rate = [data[4] for data in batch]
        return {"input_ids": input_ids, "input_mask": input_mask,
                "user_id": users_id, "item_id": items_id, "rate": rate}


class OnlySaveClsData(Dataset):
    def __init__(self, config, meta_data):
        super(OnlySaveClsData, self).__init__()
        self.data = []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        for parent_item_id, text in meta_data.items():
            input_data = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
            input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
            self.data.append({"ids": input_ids, "mask": input_mask, "parent_item_id": parent_item_id})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["parent_item_id"]


class OnlySaveClsLoader(DataLoader):
    def __init__(self, data, batch_size, shuffle=False):
        super(OnlySaveClsLoader, self).__init__(data, batch_size=batch_size, shuffle=shuffle, collate_fn=self.collate_fn)

    @staticmethod
    def collate_fn(batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        parent_item_id = [data[2] for data in batch]
        return {"input_ids": input_ids, "input_mask": input_mask, "parent_item_id": parent_item_id}


class NewData(Dataset):
    def __init__(self, config, review_data, meta_data):
        super(NewData, self).__init__()
        self.config = config
        self.data = []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        for ele in review_data:
            text, parent_id = ele['text'], ele['parent_id']
            input_data = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
            input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
            if config['use_meta']:
                item_cls = meta_data[parent_id] if parent_id in meta_data else torch.zeros(768)
                self.data.append({"ids": input_ids, "mask": input_mask, "cls": item_cls, "rate": ele['rate']})
            else:
                self.data.append({"ids": input_ids, "mask": input_mask, "rate": ele['rate']})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        if self.config['use_meta']:
            return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["rate"], self.data[idx]["cls"]
        else:
            return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["rate"]


class NewLoader(DataLoader):
    def __init__(self, data, config):
        self.config = config
        super(NewLoader, self).__init__(data, batch_size=config['bs'], collate_fn=self.collate_fn)

    def collate_fn(self, batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        rate = torch.tensor([data[2] for data in batch]).float()
        if self.config['use_meta']:
            cls = torch.stack([data[3] for data in batch])
            return {"input_ids": input_ids, "input_mask": input_mask, "rate": rate, "cls": cls}
        else:
            return {"input_ids": input_ids, "input_mask": input_mask, "rate": rate}


class ReviewClsData(Dataset):
    def __init__(self, review_data, config):
        super(ReviewClsData, self).__init__()
        self.review_data, self.data = review_data, []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        for i, ele in enumerate(self.review_data):
            input_data = self.tokenizer(ele['text'], padding='max_length', truncation=True, max_length=1024, add_special_tokens=True)
            input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
            self.data.append({"ids": input_ids, "mask": input_mask, "user_id": ele['user_id'],
                              "item_id": ele['item_id'], "rate": ele['rate'], "parent_id": ele['parent_id']})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]["user_id"], self.data[idx]["item_id"], self.data[idx]['rate'], self.data[idx]['parent_id']


class ReviewClsLoader(DataLoader):
    def __init__(self, data, batch_size, shuffle=True):
        super(ReviewClsLoader, self).__init__(data, batch_size=batch_size, shuffle=shuffle, collate_fn=self.collate_fn)

    @staticmethod
    def collate_fn(batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        users_id = [data[2] for data in batch]
        items_id = [data[3] for data in batch]
        rate = [data[4] for data in batch]
        parent_id = [data[5] for data in batch]
        return {"input_ids": input_ids, "input_mask": input_mask, "user_id": users_id, "item_id": items_id, "rate": rate, "parent_id": parent_id}


class MetaClsData(Dataset):
    def __init__(self, meta_data, config):
        super(MetaClsData, self).__init__()
        self.meta_data, self.data = meta_data, []
        self.tokenizer = BertTokenizer.from_pretrained(config['base_model'])
        for p_id, text in self.meta_data.items():
            input_data = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
            input_ids, input_mask = input_data['input_ids'], input_data['attention_mask']
            self.data.append({"ids": input_ids, "mask": input_mask, "parent_id": p_id})

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]["ids"], self.data[idx]["mask"], self.data[idx]['parent_id']


class MetaClsLoader(DataLoader):
    def __init__(self, data, batch_size, shuffle=True):
        super(MetaClsLoader, self).__init__(data, batch_size=batch_size, shuffle=shuffle, collate_fn=self.collate_fn)

    @staticmethod
    def collate_fn(batch):
        input_ids = torch.tensor([data[0] for data in batch])
        input_mask = torch.tensor([data[1] for data in batch])
        parent_id = [data[2] for data in batch]
        return {"input_ids": input_ids, "input_mask": input_mask, "parent_id": parent_id}


class NewTransData(Dataset):
    def __init__(self, data):
        super(NewTransData, self).__init__()
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class NewTransDataLoader(DataLoader):
    def __init__(self, data, config):
        self.config = config
        super(NewTransDataLoader, self).__init__(data, batch_size=config["bs"], shuffle=False, collate_fn=self.collate_fn, drop_last=True)

    def collate_fn(self, batch):
        user_id = torch.tensor([data['user_id'] for data in batch])
        item_id = torch.tensor([data['item_id'] for data in batch])
        rate = torch.tensor([data['rate'] for data in batch])
        if self.config['item']:
            user_input = torch.stack(
                [padding_item_cls(data['user_input'], self.config['max_len'], self.config['use_meta']) for data in
                 batch]).to(
                torch.float32)
            item_input = torch.stack(
                [padding_item_cls(data['item_input'], self.config['max_len'], self.config['use_meta']) for data in
                 batch]).to(
                torch.float32)
        else:
            user_input = torch.stack([padding_cls(data['user_input'], self.config['max_len'], self.config['use_meta']) for data in batch]).to(torch.float32)
            item_input = torch.stack([padding_cls(data['item_input'], self.config['max_len'], self.config['use_meta']) for data in batch]).to(torch.float32)


        return {"user_id": user_id, "item_id": item_id, "rate": rate, "user_input": user_input, "item_input": item_input}


class TestData(Dataset):
    def __init__(self, data):
        super(TestData, self).__init__()
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class TestDataLoader(DataLoader):
    def __init__(self, data, config):
        self.config = config
        super(TestDataLoader, self).__init__(data, batch_size=config["bs"], shuffle=False, collate_fn=self.collate_fn, drop_last=True)

    def collate_fn(self, batch):
        user_id = torch.tensor([data['user_id'] for data in batch])
        item_id = torch.tensor([data['item_id'] for data in batch])
        rate = torch.tensor([data['rate'] for data in batch])
        user_input = [padding_cls(torch.tensor(data['user_input']), self.config['max_len'], self.config['use_meta']) for data in batch]
        item_input = [padding_cls(torch.tensor(data['item_input']), self.config['max_len'], self.config['use_meta']) for data in batch]
        user_input = torch.stack(user_input).to(torch.float32)
        item_input = torch.stack(item_input).to(torch.float32)

        return {"user_id": user_id, "item_id": item_id, "rate": rate, "user_input": user_input, "item_input": item_input}
