import argparse

def config_save_cls():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0, help="Random Seed (Default: 0)")
    parser.add_argument("--review_path", type=str, default='./dataset/Industrial_and_Scientific_8_fold.jsonl')
    # parser.add_argument("--review_path", type=str, default='/home/MMReco2021/yangshuo/qwen/data/Baby_Products.jsonl')
    parser.add_argument("--review_cls_path", type=str, default='./dataset/Industrial_and_Scientific_8_review_cls.json')
    parser.add_argument("--base_model", type=str, default="bert-base-cased", help="base model of bert")
    parser.add_argument("--bs", type=int, default=256, help="batch_size")
    parser.add_argument("--test", action="store_false", default=False)
    parser.add_argument("--yuan", action="store_false", default=False)
    args = parser.parse_args()
    args = vars(args)
    return args


def config_new_transformer():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0, help="random seed")
    parser.add_argument("--bs", type=int, default=128, help="batch_size")
    parser.add_argument("--max_len", type=int, default=10, help="max sequence length")
    parser.add_argument("--dropout", type=int, default=0.3, help="dropout rate")
    parser.add_argument("--layer_num", type=int, default=4, help="transformer layer number")
    parser.add_argument("--train_ratio", type=int, default=0.7, help="validation ratio")
    parser.add_argument("--val_ratio", type=int, default=0.10, help="validation ratio")
    parser.add_argument("--test_ratio", type=int, default=0.10, help="test ratio")
    parser.add_argument("--epochs", type=int, default=10, help="train epochs")
    parser.add_argument("--optim", type=str, default="Adam", help="optimizer")
    parser.add_argument("--lr", type=float, default=1e-4, help="learning rate")
    parser.add_argument("--user_dim", type=int, default=10000, help="user dimension")
    parser.add_argument("--item_dim", type=int, default=10000, help="item dimension")
    parser.add_argument("--match_loss_weight", type=float, default=0.2, help="match loss weight")
    parser.add_argument("--margin", type=float, default=1.0, help="margin")
    parser.add_argument("--temperature", type=float, default=0.1, help="temperature")
    parser.add_argument("--domain", type=str, default='Baby_Products_8')
    parser.add_argument("--use_meta", action="store_false", default=False, help="use meta information")
    parser.add_argument("--test", action="store_false", default=False)
    parser.add_argument("--item", action="store_false", default=False)

    args = parser.parse_args()
    args = vars(args)
    return args
