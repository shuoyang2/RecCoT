from utils.config import config_new_transformer
from utils.help import *
from utils.Dataset import NewTransData, NewTransDataLoader
from utils.Trainer import Trainer,Trainer_item
from torch.nn.functional import mse_loss
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split
import psutil
import copy
np.random.seed(42)
def handle_user_review_escape(line):
    """Handling escape characters in the user_deview field"""
    try:
        return line.replace('\\"', '"').replace('\\\\', '\\')
    except Exception as e:
        print(f"Escape processing failed：{str(e)}")
        return line
@timeing
def process_data(config):
    data = []
    # CLS for reading comment data
    with open("dataset/{}_review_cls.json".format(config["domain"]), "r") as f:
        for line in tqdm(f):
            json_data = json.loads(line)
            json_data['cls'] = torch.tensor(json_data['cls'])
            data.append(json_data)

    from collections import defaultdict
    # Count the number of original user interactions (based on the original ID)
    user_counter = defaultdict(int)
    for d in data:
        user_counter[d["user_id"]] += 1

    filtered_data = [d for d in data if user_counter[d["user_id"]] >= 5]
    data = filtered_data
    user_index_to_id, item_index_to_id = {}, {}
    train_user_ids = set()
    train_item_ids = set()
    for d in data:
        user_id, item_id = d['user_id'], d['item_id']
        if user_id not in user_index_to_id:
            user_index_to_id[user_id] = len(user_index_to_id)
        if item_id not in item_index_to_id:
            item_index_to_id[item_id] = len(item_index_to_id)
            train_user_ids.add(d['user_id'])
            train_item_ids.add(d['item_id'])


    user_len, item_len = len(user_index_to_id), len(item_index_to_id)
    config['user_dim'], config['item_dim'] = user_len + 1, item_len + 1
    print("用户的总数是{}\t商品的总数是{}".format(user_len, item_len))

    for d in data:
        d['user_id'] = user_index_to_id[d['user_id']]
        d['item_id'] = item_index_to_id[d['item_id']]
    del user_index_to_id, item_index_to_id



    user_reviews, item_reviews = defaultdict(list), defaultdict(list)
    user_interactions = defaultdict(list)
    for d in data:
        u_id, i_id, p_id, r_cls = d['user_id'], d['item_id'], d['parent_id'], d['cls']

        user_reviews[u_id].append(r_cls)
        item_reviews[i_id].append(r_cls)
        user_interactions[u_id].append(i_id)

    for i, ele in enumerate(data):
        u_id, i_id, rate = ele['user_id'], ele['item_id'], ele['rate']
        u_input = torch.stack(user_reviews[u_id][-config['max_len']:] if len(user_reviews[u_id]) >= config['max_len'] else user_reviews[
                u_id])

        i_input = torch.stack(
            item_reviews[i_id][-config['max_len']:] if len(item_reviews[i_id]) >= config['max_len'] else item_reviews[
                i_id])
        data[i] = {"user_id": u_id, "item_id": i_id, "rate": rate, "user_input": u_input, "item_input": i_input}
    del user_reviews, item_reviews

    required_samples = set()
    user_dict = defaultdict(list)
    item_dict = defaultdict(list)
    for item in data:
        user_dict[item["user_id"]].append(item)
        item_dict[item["item_id"]].append(item)

    for user, samples in user_dict.items():
        chosen = random.Random(42).choice(samples)
        required_samples.add(id(chosen))


    for item, samples in item_dict.items():
        if not any(id(s) in required_samples for s in samples):
            chosen = random.Random(42).choice(samples)
            required_samples.add(id(chosen))


    required_data = [item for item in data if id(item) in required_samples]
    remaining_data = [item for item in data if id(item) not in required_samples]


    if remaining_data:
        stratify = [x["rate"] for x in remaining_data]
        train_add, test_data = train_test_split(
            remaining_data,
            test_size=0.1,
            stratify=stratify,
            random_state=42
        )
    else:
        train_add, test_data = [], []


    full_train = required_data + train_add
    test_data = test_data

    train_data, val_data = train_test_split(
        full_train,
        test_size=0.1,
        random_state=42
    )
    print("Training set length: {}\tValidation set length: {}\tTest set length: {}".format(len(train_data), len(val_data),len(test_data)))

    train_set, val_set = NewTransData(train_data), NewTransData(val_data)
    test_set = NewTransData(test_data)
    del train_data, val_data,test_data

    train_set, val_set = NewTransDataLoader(train_set, config), NewTransDataLoader(val_set, config)
    test_set=NewTransDataLoader(test_set,config)

    return train_set, val_set,test_set,user_interactions


@timeing
def train_model(train_data, model, optimizer, config, logger,user_interactions):
    model.train()
    total_loss, total_mse_loss, total_num = 0, 0, len(train_data.dataset)
    for data in train_data:
        if torch.cuda.is_available():
            data = to_cuda(data)
        out, match_loss = model(data,user_interactions)
        batch_mse_loss = mse_loss(out, data['rate'])
        loss = batch_mse_loss + config['match_loss_weight'] * match_loss
        total_mse_loss += batch_mse_loss.item() * len(data['rate'])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(data)
    total_loss, total_mse_loss = total_loss / total_num, total_mse_loss / total_num
    logger.log("train_loss:{:.6f}\ttrain_mse_loss:{:.6f}".format(total_loss, total_mse_loss))
    return total_loss


@timeing
def test_model(test_data, model, config, logger, user_interactions,min_loss=None,min_test_loss= None, test=False,):
    model.eval()
    total_loss, total_mse_loss, total_num = 0, 0, len(test_data.dataset)
    for data in test_data:
        if torch.cuda.is_available():
            data = to_cuda(data)
        if test:
            out, match_loss = model(data,user_interactions,is_test=True)
        else:
            out, match_loss = model(data,user_interactions)
        batch_mse_loss = mse_loss(out, data['rate'])
        total_mse_loss += batch_mse_loss.item() * len(data['rate'])
    total_mse_loss /= total_num
    if test:
        logger.log("test_mse_loss:{:.6f}".format(total_mse_loss))
        if total_mse_loss<min_test_loss:
            logger.log("Min MSE improved from {:.6f} to {:.6f}".format(min_test_loss, total_mse_loss))
            min_test_loss=total_mse_loss
        return min_test_loss
    else:
        logger.log("val_mse_loss:{:.6f}".format( total_mse_loss))
        if total_mse_loss < min_loss and test is False:
            logger.log("Validation MSE improved from {:.6f} to {:.6f}. Saving model.".format(min_loss, total_mse_loss))
            min_loss, state_dict = total_mse_loss, model.state_dict()
            if not os.path.exists("model/train/{}".format(config['domain'])):
                os.makedirs("model/train/{}".format(config['domain']))
            torch.save({'model_state_dict': state_dict}, "model/train/{}/_model_{}.pth".format(config['domain'], "use_meta" if config['use_meta'] else "no_meta"))  # 保存最佳模型
        return  min_loss

def print_memory_usage():
    process = psutil.Process()
    memory_info = process.memory_info()
    RSS= memory_info.rss / 1024 / 1024/1024
    VMS= memory_info.vms / 1024/1024/1024
    print(f"RSS: {RSS}, VMS: {VMS}")

    return RSS, VMS
@timeing
def main(config):
    logger = FileLogger(config, pretrain=False)
    train_set, val_set, test_set,user_interactions = process_data(config)
    if config['item']:
        trainer = Trainer_item(config)
    else:
        trainer = Trainer(config)
    if torch.cuda.is_available():
        trainer = trainer.cuda()
    optimizer = torch.optim.Adam(trainer.parameters(), lr=config["lr"])
    min_loss = float('inf')  # Initialize the minimum loss to infinity
    min_test_loss = float('inf')  # Initialize the minimum loss to infinity
    for epoch in range(config['epochs']):
        logger.log("\nepoch:{}".format(epoch))
        train_model(train_set, trainer, optimizer, config, logger,copy.deepcopy(user_interactions))  # ttain
        logger.log(print_memory_usage())
        min_loss = test_model(val_set, trainer, config, logger,copy.deepcopy(user_interactions),min_loss)  # test
        logger.log(print_memory_usage())
        min_test_loss=test_model(test_set, trainer, config, logger,copy.deepcopy(user_interactions),min_loss,min_test_loss, test=True)  # 测试
        logger.log(print_memory_usage())

if __name__ == '__main__':
    opt = config_new_transformer()
    seed_everything(opt)
    main(opt)
