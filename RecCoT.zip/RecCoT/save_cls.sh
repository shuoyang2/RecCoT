#!/bin/bash
#
#SBATCH --job-name=bert
#SBATCH --output=./output/output_%j.txt
#SBATCH --error=./output/errors_%j.txt
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=90G
# 申请1个GPU; 例如使用--gres=gpu:2来申请两个或者更多GPU
#SBATCH --gres=gpu:1

# 明确指定并行参数
python3 save_cls.py

