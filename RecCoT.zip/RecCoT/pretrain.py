import torch
from transformers import BertTokenizer, BertModel, BertConfig
from torch import nn
from torch.utils.data import Dataset, DataLoader
import json
import random
from tqdm import tqdm
import torch.nn.parallel
import numpy as np
from torch.optim import Adam
import argparse
from peft import LoraModel,get_peft_model,LoraConfig
import pandas as pd
import os
from collections import defaultdict
parser = argparse.ArgumentParser()
parser.add_argument("-rs", dest="random_seed", type=int, default=42, help="Random Seed (Default: 1337)")
parser.add_argument("-dc", dest="disable_cuda", type=int, default=0,
                    help="Disable CUDA? (Default: 0, i.e. run using GPU (if available))")
parser.add_argument("-gpu", dest="gpu", type=int, default=0, help="Which GPU to use? (Default: 0)")
parser.add_argument("-vb", dest="verbose", type=int, default=1,
                    help="Show debugging/miscellaneous information? (Default: 0, i.e. Disabled)")
parser.add_argument("-die", dest="disable_initial_eval", type=int, default=0,
                    help="Disable initial Dev/Test evaluation? (Default: 0, i.e. Disabled)")
parser.add_argument("-mve", dest="model_val_per_epoch", type=int, default=1,
                    help="Perform validation and save model every n epochs (Default: 1)")

args = parser.parse_args()

# Check for availability of CUDA and execute on GPU if possible
args.use_cuda = not args.disable_cuda and torch.cuda.is_available()
del args.disable_cuda
print(torch.cuda.is_available())

# Initial Setup
np.random.seed(args.random_seed)
torch.manual_seed(args.random_seed)
def process_meta_data(meta_path):
    meta_data = defaultdict()
    with (open(meta_path, "r") as f):
        for line in tqdm(f):
            json_data = json.loads(line.strip())
            parent_item_id = json_data['parent_asin']
            description = " description: None"

            if 'description' in json_data:
                if len(json_data['description']) >= 1:
                    description = " The description is: "
                    idx=0
                    for des in json_data['description']:
                        description += des
            features = " features: None"

            if 'features' in json_data:
                if len(json_data['features']) >= 1:
                    features = " The features are: "
                    idx = 0
                    for feature in json_data['features']:
                        features += feature
            meta_data[parent_item_id] =  description+" " + features

    return meta_data
def split_data(data, train_ratio, eval_ratio):
    np.random.shuffle(data)
    num_total = len(data)

    num_train = int(num_total * train_ratio)
    num_eval = int(num_total * eval_ratio)

    train_data = data[:num_train]
    eval_data = data[num_train:num_train + num_eval]

    return train_data, eval_data

def process_data(raw_path):

    data = []
    with open(raw_path, 'r') as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)
    user_counts = defaultdict(int)
    for item in data:
        user_counts[item["user_id"]] += 1
    data = [item for item in data if user_counts[item["user_id"]] >= 5]  # Only retain users with more than 5 interactions

    preform_data = []
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
    for example in tqdm(data):
        review = example['text']
        label = example['rating']
        input_tokens = tokenizer(review, padding='max_length', truncation=True, max_length=1024, add_special_tokens=True)
        input_id_tensor = torch.tensor(input_tokens['input_ids'])
        attention_mask_tensor = torch.tensor(input_tokens['attention_mask'])
        label_tensor = torch.tensor(label)
        preform_data.append({'input_id_tensor': input_id_tensor,
                             'attention_mask_tensor': attention_mask_tensor,
                             'label_tensor': label_tensor})

    return preform_data

def process_data_meta(raw_path, meta_path):
    data = []
    meta_data=process_meta_data(meta_path)
    with open(raw_path, 'r') as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)
    user_counts = defaultdict(int)
    for item in data:
        user_counts[item["user_id"]] += 1
    data = [item for item in data if user_counts[item["user_id"]] >= 5]  # Only retain users with more than 5 interactions
    for d in data:
        d['text'] += meta_data[d['parent_asin']]

    preform_data = []
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')

    for example in tqdm(data):
        review = example['text']
        label = example['rating']
        input_tokens = tokenizer(review, padding='max_length', truncation=True, max_length=1024, add_special_tokens=True)
        input_id_tensor = torch.tensor(input_tokens['input_ids'])
        attention_mask_tensor = torch.tensor(input_tokens['attention_mask'])
        label_tensor = torch.tensor(label)
        preform_data.append({'input_id_tensor': input_id_tensor,
                             'attention_mask_tensor': attention_mask_tensor,
                             'label_tensor': label_tensor})

    return preform_data




def evaluate(model, eval_data):
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    batch_size = 4
    val_dataloader = DataLoader(eval_data, batch_size=batch_size, shuffle=True)
    model.eval()
    # Evaluate the model on the validation set after each training cycle ends
    total_predictions_val = 0
    total_mse_val = 0.0
    model.eval()
    with torch.no_grad():
        for batch_val in tqdm(val_dataloader):
            input_ids_val = batch_val['input_id_tensor'].to(device)
            attention_mask_val = batch_val['attention_mask_tensor'].to(device)
            labels_val = batch_val['label_tensor'].squeeze().to(device)

            output_val = model(input_ids_val, attention_mask_val)
            total_predictions_val += len(output_val)
            mse_val = compute_mse(output_val, labels_val)
            total_mse_val += mse_val * len(output_val)

    mse_val = total_mse_val / total_predictions_val
    return mse_val

def compute_mse(predictions, labels):
    mse_loss = nn.MSELoss()
    mse = mse_loss(predictions, labels)
    return mse.item()


class BertRegressor(nn.Module):
    def __init__(self, dropout=0.5):
        super(BertRegressor, self).__init__()

        config = BertConfig.from_pretrained('bert-base-cased')
        original_max_len = 512  # The position encoding length of the original BERT
        new_max_len = 1024  # Length of new position code
        config.max_position_embeddings = new_max_len

        self.bert = BertModel(config)

        pretrained_model = BertModel.from_pretrained('bert-base-cased')
        pretrained_dict = pretrained_model.state_dict()

        filtered_dict = {
            k: v for k, v in pretrained_dict.items()
            if "position_embeddings" not in k
        }
        self.bert.load_state_dict(filtered_dict, strict=False)

        # Initialize new position encoding
        with torch.no_grad():
            original_pos_weights = pretrained_model.embeddings.position_embeddings.weight.data

            new_pos_weights = torch.zeros((new_max_len, original_pos_weights.shape[1]))

            new_pos_weights[:original_max_len] = original_pos_weights

            new_pos_weights[original_max_len:] = original_pos_weights[:new_max_len - original_max_len]

            self.bert.embeddings.position_embeddings.weight.data = new_pos_weights.to(
                self.bert.embeddings.position_embeddings.weight.device
            )

        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(768, 1)
        self.relu = nn.ReLU()

    def forward(self, input_id, mask):
        _, pooled_output = self.bert(input_ids=input_id, attention_mask=mask, return_dict=False)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.linear(dropout_output)
        return linear_output.squeeze(-1)

# 自定义数据集类
class MyDataset(torch.utils.data.Dataset):
    def __init__(self, file_path):
        self.data = pd.read_csv(file_path)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        input_id_tensor = torch.tensor(eval(self.data.iloc[index]['input_ids']))
        attention_mask_tensor = torch.tensor(eval(self.data.iloc[index]['attention_masks']))
        label_tensor = torch.tensor(self.data.iloc[index]['labels'])


        return {'input_id_tensor': input_id_tensor,
                'attention_mask_tensor': attention_mask_tensor,
                'label_tensor': label_tensor}


def train(model, train_data, eval_data):
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")

    if use_cuda:
        model = model.cuda()

    # checkpoint_path = "pretrain/Software_fold/my_model.pth"
    # if os.path.exists(checkpoint_path):
    #     checkpoint = torch.load(checkpoint_path)
    #     model.load_state_dict(checkpoint['model_state_dict'])
    #     start_epoch = checkpoint['last_epoch']
    #     print(f"Resuming training from Epoch: {start_epoch}")
    # else:
    #     start_epoch =0
    #     print(f"Starting training from:{start_epoch}")


    # step1. parameter configuration
    R = 32
    LORA_ALPHA = 32
    LORA_DROPOUT = 0.2
    TARGET_MODULES = ["query", "value", "linear", "dense"]

    config = LoraConfig(
        r=R,
        lora_alpha=LORA_ALPHA,
        target_modules=TARGET_MODULES,
        lora_dropout=LORA_DROPOUT,
        bias="none",
    )

    # step2. Obtain LoRA model
    model = get_peft_model(model, config)
    model.print_trainable_parameters()
    # Load pre-trained BERT model parameters
    checkpoint = torch.load('./pretrain/Software_8/my_model.pth')
    model.load_state_dict(checkpoint['model_state_dict'],False)
    print("loading saving model success")
    optimizer = Adam(model.parameters(), lr=1e-5)
    num_epochs = 4
    batch_size = 4
    min_mse = 100

    train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    model.train()
    for epoch in range(num_epochs):
        total_loss_train = 0
        for idx, batch in enumerate(tqdm(train_dataloader)):
            input_ids = batch['input_id_tensor'].to(device)
            attention_mask = batch['attention_mask_tensor'].to(device)
            labels = batch['label_tensor'].squeeze().to(device)
            outputs = model(input_ids, attention_mask)
            loss_fn = nn.MSELoss()
            loss = loss_fn(outputs, labels)
            total_loss_train += loss.item()
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

            if args.verbose and (idx + 1) % 100000 == 0:
                print(f"Epoch: {epoch + 1}, Batch: {idx + 1}, Loss: {loss.item()}")
                # Save point settings
            if (idx + 1) % (len(train_dataloader) // 4) == 0:
                print(f"Saving checkpoint at Epoch: {epoch + 1}, Batch: {idx + 1}")
                state_dict = model.state_dict()
                torch.save({'last_epoch': epoch + 1, 'model_state_dict': state_dict},
                           f"./pretrain/Software_8/checkpoint_epoch{epoch + 1}_batch{idx + 1}.pth")
        if (epoch + 1) % args.model_val_per_epoch == 0:
            mse = evaluate(model, eval_data)
            print(f"Epoch: {epoch + 1}, Validation MSE: {mse}")
            if mse < min_mse:
                min_mse = mse
                state_dict = model.state_dict()
                torch.save({'last_epoch': epoch + 1, 'model_state_dict': state_dict}, "./pretrain/Software_8/my_model.pth")

        average_loss_train = total_loss_train / len(train_dataloader)
        print(f"Epoch: {epoch + 1}, Average Training Loss: {average_loss_train}")

model = BertRegressor()
# raw_path="./dataset/Software.jsonl"
# meta_path="./dataset/meta_Software.jsonl"
# print(raw_path,meta_path)
# data = process_data_meta(raw_path,meta_path)
raw_path="./dataset/Software_fold.jsonl"
print(raw_path)
data = process_data(raw_path)
train_data, eval_data = split_data(data, 0.8,0.2)
train(model, train_data,eval_data)
print("Successfully!")