import json
from tqdm import tqdm

def rename_fields_merge(files, output_path):

    field_mapping = {
        "user_id": "user_id",
        "item_id": "asin",
        "parent_id": "parent_asin",
        "user_rating": "rating",
        "user_review": "text"
    }

    with open(output_path, 'w', encoding='utf-8') as out_f:
        for file_path in files:
            with open(file_path, 'r', encoding='utf-8') as in_f:
                for line in tqdm(in_f, desc=f"process {file_path}"):
                    try:
                        data = json.loads(line.strip())

                        new_data = {}
                        for old_key, new_key in field_mapping.items():
                            new_data[new_key] = data[old_key]


                        out_f.write(json.dumps(new_data, ensure_ascii=False) + '\n')
                    except Exception as e:
                        print(f"Processing failed rows: {line[:50]}... | error: {str(e)}")
                        continue


if __name__ == "__main__":
    input_files = [
        "./qwen/data/Amazon_Fashion/val_fold0.jsonl",
        "./qwen/data/Amazon_Fashion/val_fold1.jsonl",
        "./qwen/data/Amazon_Fashion/test_fold0.jsonl"
    ]

    rename_fields_merge(input_files, "./dataset/Amazon_Fashion_fold.jsonl")
    print("sucess！")
