import torch
import tqdm
from utils.Dataset import ReviewClsData, ReviewClsLoader, MetaClsData, MetaClsLoader
from utils.help import *
from utils.config import config_save_cls
from utils.Trainer import SaveClsModel
from sklearn.model_selection import train_test_split


def process_review_data(config):
    all_data = []
    with open(config["review_path"], "r") as f:
        for line in f:
            json_data = json.loads(line.strip())
            all_data.append({
                "user_id": json_data["user_id"],
                "item_id": json_data["asin"],
                "parent_id": json_data["parent_asin"],
                "text": json_data["text"],
                "rate": json_data["rating"]
            })
            if len(all_data) >= 1000 and config["test"]:
                break

    from collections import defaultdict
    # Count the number of original user interactions (based on the original ID)
    user_counter = defaultdict(int)
    for d in all_data:
        user_counter[d["user_id"]] += 1

    # Filter and retain users with more than 5 interactions and all their data
    filtered_data = [d for d in all_data if user_counter[d["user_id"]] >= 20]
    all_data = filtered_data

    global_user_index = {}
    global_item_index = {}
    for d in all_data:
        user_id, item_id = d["user_id"], d["item_id"]
        if user_id not in global_user_index:
            global_user_index[user_id] = len(global_user_index)
        if item_id not in global_item_index:
            global_item_index[item_id] = len(global_item_index)

    # Convert the ID of the entire data to a global index
    for d in all_data:
        d["user_id"] = global_user_index[d["user_id"]]
        d["item_id"] = global_item_index[d["item_id"]]

    return all_data, len(global_item_index), global_user_index, global_item_index

def save_cls_review(config):
    model = SaveClsModel().eval().cuda()
    review_data, item_dim, _, _ = process_review_data(config)
    review_dataset = ReviewClsData(review_data, config)
    dataloader = ReviewClsLoader(review_dataset, config['bs'], shuffle=False)
    # Clear old files
    output_path = config['review_cls_path']
    if os.path.exists(output_path):
        os.remove(output_path)
    with torch.no_grad():
        for batch in tqdm.tqdm(dataloader):
            input_ids = batch['input_ids'].cuda()
            input_mask = batch['input_mask'].cuda()
            # Forward calculation
            cls = model(input_ids, input_mask).cpu().numpy()
            # Build the current batch data
            batch_cls = []
            for i in range(len(batch['user_id'])):
                batch_cls.append({
                    "user_id": batch['user_id'][i],
                    "item_id": batch['item_id'][i],
                    "rate": batch['rate'][i],
                    "parent_id": batch['parent_id'][i],
                    "cls": cls[i].tolist()
                })
            # Real time writing to the current batch
            save_cls(batch_cls, output_path, mode='a')
            del input_ids, input_mask, cls
            torch.cuda.empty_cache()
if __name__ == '__main__':
    opt = config_save_cls()
    seed_everything(opt)
    print_config(opt)
    save_cls_review(opt)

